#!/bin/bash
echo "Private keys with passphrases are not supported." >&2
exit 1
